const usuario = {
    nombre: 'Diego',
    apellido: 'Salazar',
    edad: 21,
    direccion: {
      calle: 'Villa los corales',
      numero: 123,
      ciudad: 'Concepción',
      pais: 'Chile'
    },
    contactos: {
      telefono: '123456789',
      email: 'diegosalazar@example.com',
      redesSociales: {
        instagram: '@diego',
      }
    },
    intereses: ['Programación', 'Música', 'Ajedrez']
  };

// 1_
const { nombre, apellido} = usuario;
const {ciudad } = usuario.direccion;
console.log(nombre);
console.log(apellido);
console.log(ciudad);

// 2_
const primerInteres = usuario.intereses[0];

// 3_
const email = usuario.contactos.email;
const instagram = usuario.contactos.redesSociales;
console.log(email);
console.log(instagram);

//4_ 
const calleUsuario = usuario.direccion.calle;
const numeroUsuario = usuario.direccion.numero;
console.log(calleUsuario);
console.log(numeroUsuario);
