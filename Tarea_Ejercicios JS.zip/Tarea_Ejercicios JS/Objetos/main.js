const persona ={
    nombre: "Juan",
    edad: 30,
    genero: "masculino"
}
console.log(persona);

const caja ={
    cuadernos: 12,
    lápices: 8,
    papel: "hoja de oficio",
    fotografias: 18,
    estado: "buen estado"
}

console.log(caja, typeof(caja.cuadernos), typeof(caja.lápices), typeof(caja.papel), typeof(caja.fotografias), typeof(caja.estado));


