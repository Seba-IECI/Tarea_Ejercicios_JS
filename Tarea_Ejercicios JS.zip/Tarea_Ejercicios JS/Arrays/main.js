function suma_array(num){
    let suma = 0;
    for (let i = 0; i < num.length; i++) {
        suma += num[i];
        }
        return suma;
}

function promedio_array(num){
    let suma = 0, prom = 0;
    for (let i = 0; i < num.length; i++) {
        suma += num[i];
        prom = suma/num.length;
        }
        return prom;
}

function mayusculas (palabras){
    let mayus = "";
    for (let i = 0; i < palabras.length; i++) {
        mayus += palabras[i].toUpperCase() + " ";
        }
        return mayus;        
}

function num_pares (num){
    let pares = [];
    for (let i = 0; i < num.length; i++) {
        if (num[i] % 2 == 0) {
            pares[i] = num[i];
        }
    }
    return pares;
}

let num = [1,9,2,6,7]
console.log(suma_array(num));
console.log(promedio_array(num));
console.log(num_pares(num));

let palabras = ['huesillo', 'redondo', 'espacio', 'noctulo'];
console.log(mayusculas(palabras));


