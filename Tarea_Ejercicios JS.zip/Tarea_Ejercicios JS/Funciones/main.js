function mayuscula (palabra){
    return palabra.toUpperCase();
}
let palabra = "recorrido";
console.log(mayuscula(palabra)); 

function minuscula (palabra2){
    return palabra2.toLowerCase();
}
let palabra2 = "AMBULANCIA";
console.log(minuscula(palabra2)); 

function resta (num1, num2){
    return num1 - num2;
}
function division (num1, num2){
    return num1 / num2;
}

function multiplicar (num1, num2){
    return num1 * num2;
}

let num1=10, num2=5;
console.log(resta(num1, num2));
console.log(division(num1, num2));
console.log(multiplicar(num1, num2));

function longitud(string){
    return string.length;
}

let string = "Geografia";
console.log(longitud(string));
