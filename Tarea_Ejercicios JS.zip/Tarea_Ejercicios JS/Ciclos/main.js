// 1_
for(let i = 1; i<=10; i++){
    console.log(i);
}

// 2_
for(let i = 10; i>=1; i--){
    console.log(i);
}

// 3_
for(let i = 2; i<=10; i+=2){    
    console.log(i);    
}

// 4_
for(let i = 1; i<=10; i+=2){    
    console.log(i);    
}

// 5_
for(let i = 1; i<=10; i++){    
    if(i%3===0)
    console.log(i);    
}

// 6_
for(let i = 1; i<=10; i++){    
    if(i%3===0)
    console.log(i);    
}

// 7_
for(let i = 1; i<=10; i++){    
    if(i%3===0 && i%5===0)
    console.log(i);    
}

// 8_
for(let i = 1; i<=10; i++){    
    if(i%3===0 || i%5===0)
    console.log(i);    
}
