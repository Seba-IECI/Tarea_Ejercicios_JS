const numero1 = 15;
const numero2 = 20;
const numero3 = '25';


console.log(numero1 >= numero2); 
console.log(numero1 <= numero2); 
console.log(numero1 < numero3); 
console.log(numero3 < numero2); 
console.log(numero3 !== numero1); 
console.log(numero1 === numero2); 


