let nombre = "Sebastian";
let edad = 25;
let puedoConducir = true;

console.log(nombre);
console.log(edad);
console.log(puedoConducir);

console.log(typeof nombre);
console.log(typeof edad);
console.log(typeof puedoConducir);